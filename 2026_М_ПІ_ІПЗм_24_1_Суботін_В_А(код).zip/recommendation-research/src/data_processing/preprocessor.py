import pandas as pd


class DataPreprocessor:

    def __init__(
        self,
        min_user_interactions: int = 5,
        min_item_interactions: int = 5
    ):
        self.min_user_interactions = min_user_interactions
        self.min_item_interactions = min_item_interactions

    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.dropna()
        df = df.drop_duplicates()

        return df

    def filter_data(self, df: pd.DataFrame) -> pd.DataFrame:

        user_counts = df["user_id"].value_counts()
        valid_users = user_counts[
            user_counts >= self.min_user_interactions
        ].index

        df = df[df["user_id"].isin(valid_users)]

        item_counts = df["item_id"].value_counts()
        valid_items = item_counts[
            item_counts >= self.min_item_interactions
        ].index

        df = df[df["item_id"].isin(valid_items)]

        return df

    def sort_interactions(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.sort_values(["user_id", "timestamp"])

    def leave_one_out_split(self, df: pd.DataFrame):

        train_rows = []
        valid_rows = []
        test_rows = []

        grouped = df.groupby("user_id")

        for _, user_df in grouped:

            if len(user_df) < 3:
                continue

            user_df = user_df.sort_values("timestamp")

            train = user_df.iloc[:-2]
            valid = user_df.iloc[-2:-1]
            test = user_df.iloc[-1:]

            train_rows.append(train)
            valid_rows.append(valid)
            test_rows.append(test)

        train_df = pd.concat(train_rows)
        valid_df = pd.concat(valid_rows)
        test_df = pd.concat(test_rows)

        return train_df, valid_df, test_df

    def process(self, df: pd.DataFrame):

        df = self.clean_data(df)

        df = self.filter_data(df)

        df = self.sort_interactions(df)

        train_df, valid_df, test_df = self.leave_one_out_split(df)

        return train_df, valid_df, test_df