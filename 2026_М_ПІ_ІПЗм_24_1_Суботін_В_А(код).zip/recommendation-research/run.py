from pathlib import Path
import sys
import yaml

from src.experiment.config_manager import load_config
from src.experiment.experiment_runner import ExperimentRunner
from src.evaluation.result_analyzer import ResultAnalyzer


CONFIG_PATH = "config/experiment.yaml"


MODELS = {
    "sasrec": "SASRec",
    "bert": "BERT4Rec",
    "s3rec": "S3Rec"
}


DATASETS = {
    "Amazon-Beauty": {
        "dataset_name": "Amazon-Beauty",
        "raw_dataset_path":
            "data/raw/Amazon-Beauty/interactions.csv"
    },

    "Steam": {
        "dataset_name": "Steam",
        "raw_dataset_path":
            "data/raw/Steam/interactions.csv"
    },

    "Yelp": {
        "dataset_name": "Yelp",
        "raw_dataset_path":
            "data/raw/Yelp/interactions.csv"
    },

    "Amazon-Toys": {
        "dataset_name": "Amazon-Toys",
        "raw_dataset_path":
            "data/raw/Amazon-Toys/interactions.csv"
    },

    "Amazon-Sports": {
        "dataset_name": "Amazon-Sports",
        "raw_dataset_path":
            "data/raw/Amazon-Sports/interactions.csv"
    }
}


def print_usage():

    print(
        "\nUsage:\n"
        "python run.py <mode> <model> <dataset>\n"
    )

    print("Examples:")
    print(
        "python run.py train s3rec Amazon-Beauty"
    )

    print(
        "python run.py eval sasrec Steam\n"
    )

    print("Models:")
    for model in MODELS:
        print(f"  {model}")

    print("\nDatasets:")
    for dataset in DATASETS:
        print(f"  {dataset}")

    sys.exit(1)


def update_config(model_name, dataset_name):

    config = load_config(CONFIG_PATH)

    config["model"] = model_name

    config["dataset_name"] = \
        DATASETS[dataset_name]["dataset_name"]

    config["raw_dataset_path"] = \
        DATASETS[dataset_name]["raw_dataset_path"]

    with open(
        CONFIG_PATH,
        "w",
        encoding="utf-8"
    ) as file:

        yaml.dump(
            config,
            file,
            allow_unicode=True,
            sort_keys=False
        )

    return config


def choose_checkpoint():

    checkpoints_dir = Path(
        "results/checkpoints"
    )

    checkpoints = list(
        checkpoints_dir.glob("*.pth")
    )

    if not checkpoints:
        raise FileNotFoundError(
            "No checkpoints found"
        )

    print("\nCheckpoints:")

    for i, checkpoint in enumerate(
        checkpoints,
        start=1
    ):
        print(f"{i}. {checkpoint.name}")

    choice = int(input("\nSelect: "))

    return checkpoints[
        choice - 1
    ].name


def main():

    if len(sys.argv) != 4:
        print_usage()

    mode = sys.argv[1].lower()
    model_key = sys.argv[2].lower()
    dataset_name = sys.argv[3]

    if mode not in ["train", "eval"]:
        raise ValueError(
            "Invalid mode"
        )

    if model_key not in MODELS:
        raise ValueError(
            "Invalid model"
        )

    if dataset_name not in DATASETS:
        raise ValueError(
            "Invalid dataset"
        )

    model_name = MODELS[model_key]

    config = update_config(
        model_name,
        dataset_name
    )

    print(
        f"\n{mode.upper()} | "
        f"{config['model']} | "
        f"{config['dataset_name']}\n"
    )

    runner = ExperimentRunner(config)

    if mode == "train":

        results = runner.train()

    else:

        checkpoint_name = choose_checkpoint()

        results = runner.evaluate_checkpoint(
            checkpoint_name
        )

    print("\nResults:\n")

    ResultAnalyzer.print_results(results)

    ResultAnalyzer.save_results(
        results,
        "results/results.csv"
    )


if __name__ == "__main__":
    main()