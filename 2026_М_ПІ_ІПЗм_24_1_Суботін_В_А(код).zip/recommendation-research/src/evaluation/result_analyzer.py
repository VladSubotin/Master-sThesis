import pandas as pd


class ResultAnalyzer:

    @staticmethod
    def save_results(results: dict, output_path: str):

        df = pd.DataFrame([results])

        df.to_csv(output_path, index=False)

    @staticmethod
    def print_results(results: dict):

        print("\nEvaluation Results:\n")

        for metric, value in results.items():
            print(f"{metric}: {value:.5f}")