from pathlib import Path

import torch

from recbole.config import Config
from recbole.data import create_dataset, data_preparation
from recbole.utils import get_model
from recbole.trainer import Trainer
from recbole.utils import init_seed

from src.data_processing.loader import load_csv
from src.data_processing.preprocessor import DataPreprocessor
from src.data_processing.recbole_converter import (
    save_to_recbole_format
)


class ExperimentRunner:

    def __init__(self, config_dict):

        self.config_dict = config_dict

    def prepare_data(self):

        raw_path = self.config_dict["raw_dataset_path"]

        df = load_csv(raw_path)

        preprocessor = DataPreprocessor(
            min_user_interactions=5,
            min_item_interactions=5
        )

        train_df, valid_df, test_df = preprocessor.process(df)

        dataset_name = self.config_dict["dataset_name"]

        save_to_recbole_format(
            train_df,
            f"dataset/{dataset_name}/{dataset_name}.train.inter"
        )

        save_to_recbole_format(
            valid_df,
            f"dataset/{dataset_name}/{dataset_name}.valid.inter"
        )

        save_to_recbole_format(
            test_df,
            f"dataset/{dataset_name}/{dataset_name}.test.inter"
        )

    def _build(self):

        config = Config(
            model=self.config_dict["model"],
            dataset=self.config_dict["dataset_name"],
            config_dict=self.config_dict
        )

        init_seed(
            config["seed"],
            config["reproducibility"]
        )

        dataset = create_dataset(config)

        train_data, valid_data, test_data = data_preparation(
            config,
            dataset
        )

        model_class = get_model(config["model"])

        model = model_class(
            config,
            train_data.dataset
        ).to(config["device"])

        trainer = Trainer(config, model)

        return (
            config,
            model,
            trainer,
            train_data,
            valid_data,
            test_data
        )

    def train(self):

        self.prepare_data()

        (
            config,
            model,
            trainer,
            train_data,
            valid_data,
            test_data
        ) = self._build()

        trainer.fit(
            train_data,
            valid_data
        )

        test_result = trainer.evaluate(
            test_data,
            load_best_model=True
        )

        return test_result


    def evaluate_checkpoint(self, checkpoint_name):

        self.prepare_data()

        (
            config,
            model,
            trainer,
            train_data,
            valid_data,
            test_data
        ) = self._build()

        checkpoint_path = Path(
            f"results/checkpoints/{checkpoint_name}"
        )

        if not checkpoint_path.exists():
            raise FileNotFoundError(
                f"Checkpoint not found: {checkpoint_path}"
            )

        checkpoint = torch.load(
            checkpoint_path,
            map_location=config["device"],
            weights_only=False
        )

        model.load_state_dict(
            checkpoint["state_dict"]
        )

        model.eval()

        test_result = trainer.evaluate(
            test_data,
            load_best_model=False
        )

        return test_result