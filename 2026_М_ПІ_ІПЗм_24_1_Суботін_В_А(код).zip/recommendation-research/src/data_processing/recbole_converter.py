from pathlib import Path


def save_to_recbole_format(df, output_path: str):

    output_path = Path(output_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    columns = [
        "user_id",
        "item_id",
        "timestamp"
    ]

    df = df[columns]

    header = (
        "user_id:token\t"
        "item_id:token\t"
        "timestamp:float\n"
    )

    with open(output_path, "w", encoding="utf-8") as f:

        f.write(header)

        for _, row in df.iterrows():

            line = (
                f"{row['user_id']}\t"
                f"{row['item_id']}\t"
                f"{row['timestamp']}\n"
            )

            f.write(line)