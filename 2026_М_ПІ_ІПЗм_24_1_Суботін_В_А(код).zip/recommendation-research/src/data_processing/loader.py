import gzip
import json
import pandas as pd


def load_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def load_json_gz(path: str) -> pd.DataFrame:
    rows = []

    with gzip.open(path, "rt") as f:
        for line in f:
            rows.append(json.loads(line))

    return pd.DataFrame(rows)